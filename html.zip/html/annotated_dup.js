var annotated_dup =
[
    [ "Battery", "class_battery.html", "class_battery" ],
    [ "ConnectWindow", "class_connect_window.html", "class_connect_window" ],
    [ "InterfaceWindow", "class_interface_window.html", "class_interface_window" ],
    [ "MyWidget", "class_my_widget.html", "class_my_widget" ],
    [ "Plot", "class_plot.html", "class_plot" ],
    [ "UDP_t", "struct_u_d_p__t.html", "struct_u_d_p__t" ]
];