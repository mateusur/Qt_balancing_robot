var files =
[
    [ "battery.cpp", "battery_8cpp.html", null ],
    [ "battery.h", "battery_8h.html", [
      [ "Battery", "class_battery.html", "class_battery" ]
    ] ],
    [ "connectwindow.cpp", "connectwindow_8cpp.html", "connectwindow_8cpp" ],
    [ "connectwindow.h", "connectwindow_8h.html", "connectwindow_8h" ],
    [ "interfacewindow.cpp", "interfacewindow_8cpp.html", "interfacewindow_8cpp" ],
    [ "interfacewindow.h", "interfacewindow_8h.html", "interfacewindow_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mywidget.cpp", "mywidget_8cpp.html", null ],
    [ "mywidget.h", "mywidget_8h.html", [
      [ "MyWidget", "class_my_widget.html", "class_my_widget" ]
    ] ],
    [ "plot.cpp", "plot_8cpp.html", null ],
    [ "plot.h", "plot_8h.html", [
      [ "Plot", "class_plot.html", "class_plot" ]
    ] ],
    [ "UDPclient.cpp", "_u_d_pclient_8cpp.html", "_u_d_pclient_8cpp" ],
    [ "UDPclient.h", "_u_d_pclient_8h.html", "_u_d_pclient_8h" ]
];