var struct_u_d_p__t =
[
    [ "clientAddr", "struct_u_d_p__t.html#a11fda48491a2c873aea41e71bdc12ed7", null ],
    [ "clientSock", "struct_u_d_p__t.html#a439422392445fd31f3e28083b596283b", null ],
    [ "len", "struct_u_d_p__t.html#aaa319f96bc66fa36c873a38e4218193c", null ],
    [ "serverAddr", "struct_u_d_p__t.html#a4d57980d9d0966e2a8834762ed1daa83", null ]
];