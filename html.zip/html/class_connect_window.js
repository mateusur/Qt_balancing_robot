var class_connect_window =
[
    [ "ConnectWindow", "class_connect_window.html#a24550ef970f6b9415e331e02c51f649b", null ],
    [ "~ConnectWindow", "class_connect_window.html#a65095617a9cb354f68f9b64b700e7dc0", null ],
    [ "on_pushButton_clicked", "class_connect_window.html#a8f20f77c0f7aeeebb839966e4e0246c0", null ],
    [ "set_icon", "class_connect_window.html#a3561edf877d10dd940f94d88cf836f3c", null ],
    [ "set_pixmap", "class_connect_window.html#a741010c6017499604289165814b5138e", null ],
    [ "ui", "class_connect_window.html#ab751a37384c3c08cacce6bb51a9cdaab", null ]
];