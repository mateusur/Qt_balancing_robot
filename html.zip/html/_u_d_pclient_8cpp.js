var _u_d_pclient_8cpp =
[
    [ "UDPclient_getResp", "_u_d_pclient_8cpp.html#a81180d21cebb423f20198e2e2fb15c7a", null ],
    [ "UDPclient_init", "_u_d_pclient_8cpp.html#a2bc3a5bc4b4ef913dd1a889189d72080", null ],
    [ "UDPclient_sendReq", "_u_d_pclient_8cpp.html#a3f23f2aab3ca20124c92997351589df5", null ],
    [ "UDPclient_setSeverIPAddress", "_u_d_pclient_8cpp.html#af762689bc1f0cfc0517beaa89b3e1202", null ]
];