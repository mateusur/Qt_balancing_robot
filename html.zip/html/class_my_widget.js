var class_my_widget =
[
    [ "MyWidget", "class_my_widget.html#a4a9d659321b8e86eef35b115a767a991", null ],
    [ "~MyWidget", "class_my_widget.html#a47499f400b6a34b44ad9727f31d0948f", null ],
    [ "paintEvent", "class_my_widget.html#a4d0442f6dcb76def861f0fab9f182486", null ],
    [ "update_angle", "class_my_widget.html#a48d0fbc77f4c4adbf8ddcb4bbb0d9aa8", null ],
    [ "degrees", "class_my_widget.html#a724fedb7e80731688304ce5cb97d18c6", null ],
    [ "radToDegrees", "class_my_widget.html#a54a8635043916c105d2d6993b1bcb2da", null ],
    [ "rising", "class_my_widget.html#acf23a5e917afd3429c5507c6b470bacd", null ],
    [ "timer1", "class_my_widget.html#a46fe6467943b3f5a3e0558b982461f48", null ],
    [ "ui", "class_my_widget.html#aefb6e70f646f21b6e66606f6b855e3ea", null ]
];