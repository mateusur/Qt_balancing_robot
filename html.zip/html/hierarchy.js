var hierarchy =
[
    [ "QMainWindow", null, [
      [ "ConnectWindow", "class_connect_window.html", null ],
      [ "InterfaceWindow", "class_interface_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "Plot", "class_plot.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "Battery", "class_battery.html", null ],
      [ "MyWidget", "class_my_widget.html", null ]
    ] ],
    [ "UDP_t", "struct_u_d_p__t.html", null ]
];