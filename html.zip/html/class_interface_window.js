var class_interface_window =
[
    [ "InterfaceWindow", "class_interface_window.html#a8c6a751c66909e128c54458c89f39392", null ],
    [ "~InterfaceWindow", "class_interface_window.html#a909571c785859099190f9d538d8bc338", null ],
    [ "hello", "class_interface_window.html#af92e591da58b8af466cc958a826c623b", null ],
    [ "recive_data", "class_interface_window.html#a0313818406d123da00f1248591ea4ee2", null ],
    [ "send_degrees", "class_interface_window.html#acc1d2921deb5bad4c9d69764d51be63a", null ],
    [ "send_point", "class_interface_window.html#ac5570ff01de0d3752a252ded059685a9", null ],
    [ "set_icons", "class_interface_window.html#ab6a42210e3450569e114a16872c6cebf", null ],
    [ "set_pixmap", "class_interface_window.html#a3d547c8d3fe66f86cc6b242602bdd2ff", null ],
    [ "graph1", "class_interface_window.html#a8bf9778fa1b2d41b1ae1772533d4f7bb", null ],
    [ "graph2", "class_interface_window.html#ab4d313b17afad3ca291cebebf71b34e0", null ],
    [ "tim_data", "class_interface_window.html#a345c1eb3911df62d39e0de8d8fd0b55b", null ],
    [ "tim_elapsed", "class_interface_window.html#a59dde8ee6c93389ebcc9775d3bd5f47b", null ],
    [ "ui", "class_interface_window.html#a7f6a197a2e565284c59a4c0c8c37f9d5", null ]
];