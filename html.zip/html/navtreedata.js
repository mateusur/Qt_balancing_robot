var NAVTREE =
[
  [ "Balancing robot", "index.html", [
    [ "Dokumentacja aplikacji Robot balansujący - KIRA", "index.html", [
      [ "Wprowadzenie", "index.html#Wprowadzenie", null ],
      [ "Główne okno", "index.html#Interface_window", null ],
      [ "Okno łączenia", "index.html#Connect_window", null ],
      [ "Dokumentacja", "index.html#Dokumentacja", null ]
    ] ],
    [ "Przestrzenie nazw", null, [
      [ "Lista przestrzeni nazw", "namespaces.html", "namespaces" ]
    ] ],
    [ "Klasy", "annotated.html", [
      [ "Lista klas", "annotated.html", "annotated_dup" ],
      [ "Indeks klas", "classes.html", null ],
      [ "Hierarchia klas", "hierarchy.html", "hierarchy" ],
      [ "Składowe klas", "functions.html", [
        [ "Wszystko", "functions.html", null ],
        [ "Funkcje", "functions_func.html", null ],
        [ "Zmienne", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Pliki", null, [
      [ "Lista plików", "files.html", "files" ],
      [ "Składowe plików", "globals.html", [
        [ "Wszystko", "globals.html", null ],
        [ "Funkcje", "globals_func.html", null ],
        [ "Zmienne", "globals_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_u_d_pclient_8cpp.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';